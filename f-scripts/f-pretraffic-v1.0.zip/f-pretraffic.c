/* f-pretraffic v1.0 Monitor and Reporter */
/* $Rev: 1254 $ $Date: 2004-11-19 14:48:10 +0100 (Fri, 19 Nov 2004) $ */

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>

#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdarg.h>

#include <unistd.h>

#include <pcreposix.h>

/* our user config settings */
#include CONFIG_H

/* include a hex dump of the config file */
#include "inc-config.h"

/* some Limits */
#define TAILPOLL_RESTAT_NUM    	100

/* debug messages */

int aprintf_output = 0;

inline int aprintf(const char *format, ...) {
     va_list ap;
     int r;

     if (!aprintf_output) return 0;
     
     va_start(ap, format);
     r = vprintf(format, ap);
     va_end(ap);

     return r;
}

/*** Tail Functions: Read only the end of the log files ***/

/* data structures */

struct TAILINFO {
     const char 	*path;
     int		fd;
     ino_t		inode;
     int		stat_pollcounter;
     off_t		offset;
     char		tailbuffer[2048];
     int		tailbufferlen;
};

/* tail function */

int tail_reinit(struct TAILINFO *ti) {
     struct stat st;
     int o;

     if (ti->fd > 0) close(ti->fd);

     ti->fd = open(ti->path, O_RDONLY);
     if (ti->fd < 0) {
	  printf("Error opening %s: %s\n", ti->path, strerror(errno));
	  return 0;
     }

     if (fstat(ti->fd, &st) != 0) {
	  printf("Error in fstat of %s: %s\n", ti->path, strerror(errno));
	  close(ti->fd);
	  ti->fd = 0;
	  return 0;
     }
     ti->inode = st.st_ino;
     ti->stat_pollcounter = 0;
     aprintf("tail: stat says file is %ld bytes\n", st.st_size);

     ti->tailbufferlen = 0;
     
     ti->offset = lseek(ti->fd, - sizeof(ti->tailbuffer), SEEK_END);
     aprintf("tail: lseeked to offset %ld\n", ti->offset);

     if (read(ti->fd, ti->tailbuffer, sizeof(ti->tailbuffer)) != sizeof(ti->tailbuffer)) {
	  printf("Error reading last bytes from %s: %s\n", ti->path, strerror(errno));
	  close(ti->fd);
	  ti->fd = 0;
	  return 0;
     }

     /* printf("Read: >%s<\n", ti->tailbuffer); */
     o = sizeof(ti->tailbuffer)-1;

     while( ti->tailbuffer[o] != '\n' ) {
	  o--;
	  if (o < 0) {
	       /* printf("No new line found in backlog. Waiting for one to come.\n"); */
	       ti->tailbufferlen = -1;
	       ti->offset += sizeof(ti->tailbuffer);
	       break;
	  }
     }
     if (o >= 0) {
	  o++;
	  /* printf("last new line in buffer at %d (>%s<)\n", o, ti->tailbuffer +o); */
	  ti->tailbufferlen = sizeof(ti->tailbuffer) - o;
	  memcpy(ti->tailbuffer, ti->tailbuffer + o, ti->tailbufferlen);
	  ti->offset += sizeof(ti->tailbuffer);
     }

     /* printf("Next offset to poll: %ld\n", ti->offset); */

     return 1;

}

int tail_poll(struct TAILINFO *ti, void (*line_callback)(const char *line)) {
     struct stat st;
     int o, r, heado;

     if (!ti->fd) {
	  if (!tail_reinit(ti)) return 0;
     }

     /* every few polls we stat the file and thereby check for a rotation */
     ti->stat_pollcounter++;
     if (ti->stat_pollcounter > TAILPOLL_RESTAT_NUM) {
	  ti->stat_pollcounter = 0;

	  stat(ti->path, &st);
	  if (st.st_ino != ti->inode) {
	       if (!tail_reinit(ti)) return 0;
	  }
	  if (st.st_size < ti->offset) {
	       if (!tail_reinit(ti)) return 0;
	  }	
     }

     lseek(ti->fd, ti->offset, SEEK_SET);

     o = ti->tailbufferlen;

     if (o >= 0) {

	  heado = 0;
	  r = read(ti->fd, ti->tailbuffer + o, sizeof(ti->tailbuffer) - o);
	  if (r < 0) {
	       printf("Error reading from %s: %s\n", ti->path, strerror(errno));
	       close(ti->fd); ti->fd = 0;
	       return 0;
	  }

	  ti->offset += r;
     }
     else { /* o < 0 -> skip to first nl */

	  r = read(ti->fd, ti->tailbuffer, sizeof(ti->tailbuffer));
	  if (r < 0) {
	       printf("Error reading from %s: %s\n", ti->path, strerror(errno));
	       close(ti->fd); ti->fd = 0;
	       return 0;
	  }

	  ti->offset += r;

	  heado = 0;
	  o = 0;
	  while(o < r && heado == 0) {
	       if (ti->tailbuffer[o] == '\n') {
		    heado = o;
	       }
	       o++;
	  }
	  if (heado == 0) {
	       return 0;
	  }
     }

     while( o < ti->tailbufferlen + r ) {

	  if (ti->tailbuffer[o] == '\n') {
	       ti->tailbuffer[o] = 0;
		    
	       line_callback(ti->tailbuffer + heado);

	       heado = o+1;
	  }

	  o++;
     }

     if (heado != 0) {
	  if (o - heado > 0) {
	       memcpy(ti->tailbuffer, ti->tailbuffer + heado, o - heado);
	  }
	  ti->tailbufferlen = o - heado;
     }

     return 1;
}

/* f-glftpdlog.h (r1252): C function include for f glftpd log writer */

/* Necessary #defines: (defaults)
   GLROOT	= /glftpd
   GLLOGPATH	= /ftp-data/logs/glftpd.log
   GLLOGTAG 	= DATA
*/

#ifndef GLROOT
#warning "GLROOT #define defaults to /glftpd . Set it in your config.h"
#define GLROOT "/glftpd"
#endif

#ifndef GLLOGPATH
#warning "GLLOGPATH #define defaults to /ftp-data/logs/glftpd.log . Set it in your config.h"
#define GLLOGPATH "/ftp-data/logs/glftpd.log"
#endif

#ifndef GLLOGTAG
#warning "GLLOGTAG #define defaults to DATA. Set it in your config.h"
#define GLLOGTAG "DATA"
#endif

/* write_glftpd -> append on line at the end of the log */

void write_glftpd(const char *line) {
     FILE *glfile;

     time_t timenow = time(NULL);
     char *date = ctime(&timenow);

     glfile = fopen(GLLOGPATH, "a+");
     if (!glfile) {
	  glfile = fopen(GLROOT GLLOGPATH, "a+");
	  if (!glfile) {
	       return;
	  }
     }

     fprintf(glfile, "%.24s %s\n", date, line);

     fclose(glfile);
}

int glprintf_stdout = 0;

int glprintf(const char *format, ...) {
     va_list ap;
     char output[256], output2[290], *s1, *s2;
     int ret;

     va_start(ap, format);

     if (!glprintf_stdout) {
	  ret = vsnprintf(output, 256, format, ap);

	  strcpy(output2, GLLOGTAG);
	  strcat(output2, ": \"");
	  s1 = output;
	  s2 = output2 + strlen(output2);
	  while(*s1) {
	       if (*s1 == '"') {
		    *s2++ = '\\';
	       }
	       *s2++ = *s1++;
	  }
	  *s2++ = '"';
	  *s2 = 0;

	  write_glftpd(output2);
	  return ret;
     }
     else {
	  ret = vfprintf(stdout, format, ap);
	  fprintf(stdout, "\n");
	  return ret;
     }
}

/* end of f-glftpdlog.h */

/* f-tagreplace.h (r1252): C function include for f generic tag replacer */

enum { FTR_NONE, FTR_INTEGER, FTR_LONGLONG, FTR_DOUBLE, FTR_STRING, FTR_DATE, FTR_TIMEINTERVAL };

struct REPLACETAG {
     const char	*tag;
     int	type;
     const void	*val;
};

inline int addreplace(struct REPLACETAG *taglist, int taglistlen, const char *tag, int tagtype, const void *val) {
     int n;
     for(n = 0; n < taglistlen && taglist[n].tag; n++) { }
     if (n >= taglistlen) return -1;

     taglist[n].tag = tag;
     taglist[n].type = tagtype;
     taglist[n].val = val;

     return n;
}

inline int addreplace_integer(struct REPLACETAG *taglist, int taglistlen, const char *tag, const int *val) {
     return addreplace(taglist, taglistlen, tag, FTR_INTEGER, val);
}
inline int addreplace_longlong(struct REPLACETAG *taglist, int taglistlen, const char *tag, const long long *val) {
     return addreplace(taglist, taglistlen, tag, FTR_LONGLONG, val);
}
inline int addreplace_double(struct REPLACETAG *taglist, int taglistlen, const char *tag, const double *val) {
     return addreplace(taglist, taglistlen, tag, FTR_DOUBLE, val);
}
inline int addreplace_string(struct REPLACETAG *taglist, int taglistlen, const char *tag, const char *val) {
     return addreplace(taglist, taglistlen, tag, FTR_STRING, val);
}
inline int addreplace_date(struct REPLACETAG *taglist, int taglistlen, const char *tag, const time_t *val) {
     return addreplace(taglist, taglistlen, tag, FTR_DATE, val);
}
inline int addreplace_timeinterval(struct REPLACETAG *taglist, int taglistlen, const char *tag, const unsigned int *val) {
     return addreplace(taglist, taglistlen, tag, FTR_TIMEINTERVAL, val);
}

/* build a full replacement list: length times follows the arguments
   const char* tag, int tagtype, const char *val */
struct REPLACETAG *replacelist_malloc(int length, ...) {
     struct REPLACETAG *list;
     va_list ap;
     int n;

     list = malloc((length+1) * sizeof(struct REPLACETAG));
     memset(list, 0, (length+1) * sizeof(struct REPLACETAG));

     va_start(ap, length);

     for(n = 0; n < length; n++) {
	  list[n].tag = va_arg(ap, const char *);
	  list[n].type = va_arg(ap, int);
	  list[n].val = va_arg(ap, const void *);
     }

     va_end(ap);
     return list;
}

/* tagreplace Parameters:
   pattern = use supplied string with %TAG%s
   outbuffer = output buffer of size outlen
   taglist = array of replacement tags
*/

/* syntax %VAR-4% for integer,
   syntax %VAR-4.5% for double decimal points
   syntax %VAR-YYYY-MM-DD-hh-mm-ss% for dates
   syntax %VAR-DD% for time intervals

   following strings will be replaced in the format of a date:
   YYYY = four digit year
   YY = two digit year (avoid)
   MM = two digit month number
   MMM = three letter abbreviation for the month
   MMMM = full month name
   DD = two digit day of month number
   hh = two digit 24h-clock time of day
   ii = two digit 12h-clock time of day
   pp = either am or pm of 12h-clock
   mm = two digit minute
   ss = two digit seconds
   other character sequences are copied.

   If no format is specified for date types it defaults to
   YYYY-MM-DD HH:MM:SS
*/

const char* tagreplace(const char *pattern, char *outbuffer, int outlen, struct REPLACETAG *taglist) {
     char *out = outbuffer;
     int outleft;

     if (!pattern) return "(null)";

     while( *pattern != 0 && (outleft = outlen - (out - outbuffer) - 1) > 0) {
	  if (*pattern == '%') {
	       if (pattern[1] == '%') {
		    *out++ = '%';
		    pattern++;
	       }
	       else if (strncasecmp(pattern,"%BOLD%",6) == 0) {
		    *out++ = 0x02;
		    pattern += 5;
	       }
	       else if (strncasecmp(pattern,"%COLOR%",7) == 0) {
		    *out++ = 0x03;
		    pattern += 6;
	       }
	       else if (strncasecmp(pattern,"%ULINE%",7) == 0) {
		    *out++ = 0x1F;
		    pattern += 6;
	       }
	       else {
		    int bad = 0, n, sl;
		    int digits = 0, decimals = 0;

		    int haveformated = 0;
		    char formated[256];

		    for(n = 0; taglist && taglist[n].tag; n++) {
			 if (taglist[n].type == FTR_NONE) continue;

			 sl = strlen(taglist[n].tag);
			 if (strncasecmp(pattern+1, taglist[n].tag, sl) != 0) continue;

			 if (pattern[1+sl] == '-') {
			      if (taglist[n].type == FTR_INTEGER || taglist[n].type == FTR_LONGLONG) {
				   const char *modifier = pattern + 1+sl+1;

				   while(*modifier != '%') {
					if (*modifier >= '0' && *modifier <= '9') {
					     digits = digits * 10 + (*modifier - '0');
					}
					else { bad = 1; break; }
					modifier++;
					sl++;
				   }
				   if (bad) continue;
				   sl++;
			      }
			      else if (taglist[n].type == FTR_STRING) {
				   const char *modifier = pattern + 1+sl+1;

				   while(*modifier != '%') {
					if (*modifier >= '0' && *modifier <= '9') {
					     digits = digits * 10 + (*modifier - '0');
					}
					else { bad = 1; break; }
					modifier++;
					sl++;
				   }
				   if (bad) continue;
				   sl++;
			      }
			      else if (taglist[n].type == FTR_DOUBLE) {
				   const char *modifier = pattern + 1+sl+1;
				   int *val = &digits;
				   while(*modifier != '%') {
					if (*modifier >= '0' && *modifier <= '9') {
					     *val = *val * 10 + (*modifier - '0');
					}
					else if (*modifier == '.' && taglist[n].type == FTR_DOUBLE) {
					     if (val == &digits) { val = &decimals; }
					     else { bad = 1; break; }
					}
					else { bad = 1; break; }
					modifier++;
					sl++;
				   }
				   if (bad) continue;
				   sl++;
			      }
			      else if (taglist[n].type == FTR_DATE) {
				   const char *modifier = pattern + 1+sl+1;
				   char *outf = formated;
				   const char *addtoout;
				   struct tm *localtimeconv = NULL;

				   if (taglist[n].val) {
					localtimeconv = localtime((time_t*)taglist[n].val);
				   }				   

				   while(*modifier != '%') {
					if (outf + 16 > formated + sizeof(formated)) { bad = 1; break; }

					addtoout = NULL;

					if (*(long*)modifier == *(long*)"YYYY") {
					     addtoout = "%Y";
					     modifier += 3; sl += 3;
					} 
					else if (*(short*)modifier == *(short*)"YY") {
					     addtoout = "%y";
					     modifier += 1; sl += 1;
					}
					else if (*(long*)modifier == *(long*)"MMMM") {
					     addtoout = "%B";
					     modifier += 3; sl += 3;
					}
					else if (*(short*)modifier == *(short*)"MM" &&
					         *(modifier+2) == 'M')
					{
					     addtoout = "%b";
					     modifier += 2; sl += 2;
					}
					else if (*(short*)modifier == *(short*)"MM") {
					     addtoout = "%m";
					     modifier += 1; sl += 1;
					}
					else if (*(short*)modifier == *(short*)"DD") {
					     addtoout = "%d";
					     modifier += 1; sl += 1;
					}
					else if (*(short*)modifier == *(short*)"hh") {
					     addtoout = "%H";
					     modifier += 1; sl += 1;
					}
					else if (*(short*)modifier == *(short*)"ii") {
					     addtoout = "%I";
					     modifier += 1; sl += 1;
					}
					else if (*(short*)modifier == *(short*)"pp") {
					     addtoout = "%P";
					     modifier += 1; sl += 1;
					}
					else if (*(short*)modifier == *(short*)"mm") {
					     addtoout = "%M";
					     modifier += 1; sl += 1;
					}
					else if (*(short*)modifier == *(short*)"ss") {
					     addtoout = "%S";
					     modifier += 1; sl += 1;
					}
					else {
					     *outf++ = *modifier;
					}

					if (addtoout) {
					     if (localtimeconv) {
						  outf += strftime(outf, outf - formated + sizeof(formated) - 8,
								   addtoout, localtimeconv);
					     }
					     else {
						  *outf++ = 'N'; *outf++ = 'N';
					     }
					}

					modifier++;
					sl++;
				   }
				   if (bad) continue;
				   if (outf > formated) {
					haveformated = 1;
					*outf = 0;
				   }
				   sl++;
			      }
			      else {
				   continue;
			      }
			 }
			 else if (pattern[1+sl] != '%') continue;

			 if (taglist[n].type == FTR_INTEGER) {
			      out += snprintf(out, outleft, "%*ld", digits, *(long int*)taglist[n].val);
			 }
			 else if (taglist[n].type == FTR_LONGLONG) {
			      out += snprintf(out, outleft, "%*lld", digits, *(long long int*)taglist[n].val);
			 }
			 else if (taglist[n].type == FTR_STRING) {
			      out += snprintf(out, outleft, "%*s", digits, (const char*)taglist[n].val);
			 }
			 else if (taglist[n].type == FTR_DOUBLE) {
			      out += snprintf(out, outleft, "%*.*f", digits, decimals, *(double*)taglist[n].val);
			 }
			 else if (taglist[n].type == FTR_DATE) {
			      if (haveformated) {
				   out += snprintf(out, outleft, "%s", formated);
			      }
			      else if (!taglist[n].val) {
				   out += snprintf(out, outleft, "(nulldate)");
			      }
			      else {
				   out += strftime(out, outleft, "%Y-%m-%d %H:%M:%S", localtime((time_t*)taglist[n].val));
			      }
			 }
			 else {
			      out += snprintf(out, outleft, "ERRORinPROG");
			 }			 
			 
			 pattern += sl + 1;
			 break;
		    }
		    if (!taglist[n].tag) {
			 *out++ = *pattern;
		    }
	       }	       
	  }
	  else {
	       *out++ = *pattern;
	  }

	  pattern++;
     }

     *out = 0;
     return outbuffer;
}

/* end of f-tagreplace.h */

/*** Statistics Accumulation ***/

struct USERSTATS {
     int	used;
     char	username[32];
     char	groupname[32];
     int	outbytes;
     int	outsecs;
};

struct RLSSTATS {

     int	used;

     char	rlsname[256];
     int	rlssize;
     time_t	pretime;

     time_t	mtime;

     unsigned	outbytes;
     unsigned	outsecs;

     struct USERSTATS *userlist;
     int      	userlistlen;
};

struct RLSSTATS *rlsstatslist = NULL;
int rlsstatslistlen = 0;

struct RLSSTATS *getunusedrlsstats() {
     int n = 0;

     while(n < rlsstatslistlen) {
	  if (!rlsstatslist[n].used) {
	       return rlsstatslist + n;
	  }
	  n++;
     }

     if (!rlsstatslist) { 
	  rlsstatslistlen += 5;
	  rlsstatslist = malloc(sizeof(struct RLSSTATS) * rlsstatslistlen);
	  memset(rlsstatslist, 0, sizeof(struct RLSSTATS) * rlsstatslistlen);
     }
     else {
	  rlsstatslist = realloc(rlsstatslist, (rlsstatslistlen+5) * sizeof(struct RLSSTATS));
	  memset(rlsstatslist + rlsstatslistlen, 0, 5 * sizeof(struct RLSSTATS));
	  rlsstatslistlen += 5;
     }

     return rlsstatslist + rlsstatslistlen - 4;
}

struct RLSSTATS *findrlsstats(const char *rlsname) {
     int n;

     for(n = 0; n < rlsstatslistlen; n++) {
	  if (!rlsstatslist[n].used) continue;

	  if (strcmp(rlsstatslist[n].rlsname, rlsname) != 0) continue;

	  return rlsstatslist + n;
     }

     return NULL;
}

struct USERSTATS *getunuseduserstats(struct RLSSTATS *st) {
     int n = 0;

     while(n < st->userlistlen) {
	  if (!st->userlist[n].used) {
	       return st->userlist + n;
	  }
	  n++;
     }

     if (!st->userlist) { 
	  st->userlistlen = 20;
	  st->userlist = malloc(sizeof(struct USERSTATS) * st->userlistlen);
	  memset(st->userlist, 0, sizeof(struct USERSTATS) * st->userlistlen);
     }
     else {
	  st->userlist = realloc(st->userlist, (st->userlistlen+5) * sizeof(struct USERSTATS));
	  memset(st->userlist + st->userlistlen, 0, 5 * sizeof(struct USERSTATS));
	  st->userlistlen += 5;
     }

     return st->userlist + st->userlistlen - 5;
}

struct USERSTATS *finduserstats(struct RLSSTATS *st, const char *username) {
     int n;

     for(n = 0; n < st->userlistlen; n++) {
	  if (!st->userlist[n].used) continue;

	  if (strcmp(st->userlist[n].username, username) != 0) continue;

	  return st->userlist + n;
     }

     return NULL;
}

struct USERSTATS *getmaxuserstats(struct RLSSTATS *st) {
     int n, bps, maxbps = 0;
     struct USERSTATS *umax = NULL;

     for(n = 0; n < st->userlistlen; n++) {
	  if (!st->userlist[n].used) continue;
	  
	  bps = st->userlist[n].outbytes / (st->userlist[n].outsecs > 0 ? st->userlist[n].outsecs : 1);
	  
	  if (maxbps >= bps) continue;
	  
	  maxbps = bps;
	  umax = st->userlist + n;
     }

     return umax;
}

int getnumuser(struct RLSSTATS *st) {
     int n, c;
     
     c = 0;
     for(n = 0; n < st->userlistlen; n++) {
	  if (!st->userlist[n].used) continue;
	  
	  c++;
     }

     return c;
}

/*** Line Parsers ***/

void line_xferlog(const char *lineconst) {

     static regex_t reg_pattern;
     static int reg_pattern_allocated = 0;
     static const char *patternstr = "^[A-Za-z]{3} [A-Za-z]{3}[ ]{1,2}[0-9]{1,2} [0-9]{2}:[0-9]{2}:[0-9]{2} [0-9]{4} ([0-9]+) ([^ ]+) ([0-9]+) ([^ ]+) ([ab]) _ ([io]) r ([^ ]+) ([^ ]+) [01] ([^ ]+)";
     regmatch_t reg_match[20];

     char *line = strdup(lineconst);
     
     if (!reg_pattern_allocated) {
	  if( regcomp(&reg_pattern, patternstr, REG_EXTENDED) ) {
	       printf("Error compiling xferlog regex pattern.");
	       exit(-1);
	  }
	  reg_pattern_allocated = 1;
     }

     if (regexec(&reg_pattern, line, 20, reg_match, 0)) {
	  aprintf("xfer :: %s\n",line);
	  free(line);
	  return;
     }

     {
	  const char *time_str = line + reg_match[1].rm_so;
	  const char *size_str = line + reg_match[3].rm_so;
	  const char *filepath = line + reg_match[4].rm_so;
	  char inout = line[reg_match[6].rm_so];
	  const char *username = line + reg_match[7].rm_so;	  
	  const char *groupname = line + reg_match[8].rm_so;	  

	  int bytes = atoi(size_str);
	  int secs = atoi(time_str);

	  line[reg_match[1].rm_eo] = 0;
	  line[reg_match[3].rm_eo] = 0;
	  line[reg_match[4].rm_eo] = 0;
	  line[reg_match[7].rm_eo] = 0;
	  line[reg_match[8].rm_eo] = 0;

	  if (inout == 'i') {
	       free(line);
	       return;
	  }

	  aprintf("xfer > time = %s; rls = %s; byte = %s; speed = %.1f; inout = %c; %s/%s\n",
		  time_str, filepath, size_str, (float)bytes / 1024 / (secs > 0 ? secs : 0), inout, username, groupname);
	  
	  {
	       static regex_t reg_path;
	       static int reg_path_allocated = 0;
	       char *rlsname;
	       struct RLSSTATS *stats;
	       struct USERSTATS *ustats;

	       if (!reg_path_allocated) {
		    if( regcomp(&reg_path, XFERLOGRLSREGEX, REG_EXTENDED) ) {
			 printf("Error. Cannot compile XFERLOGRLSREGEX pattern");
			 exit(-1);
		    }
		    reg_path_allocated = 1;
	       }
	  
	       if (regexec(&reg_path, filepath, 20, reg_match, 0)) {
		    aprintf("xfer > Error. Path pattern doesnt match: %s\n", filepath);
		    free(line);
		    return;
	       }

	       rlsname = strndup(filepath + reg_match[XFERLOGRLSREGMATCH].rm_so,
				 reg_match[XFERLOGRLSREGMATCH].rm_eo - reg_match[XFERLOGRLSREGMATCH].rm_so);

	       stats = findrlsstats(rlsname);
	       if (!stats) {
		    free(line);
		    free(rlsname);
		    return;
	       }

	       stats->mtime = time(NULL);	       
	       stats->outbytes += bytes;
	       stats->outsecs += secs;

	       ustats = finduserstats(stats, username);
	       if (!ustats) {
		    ustats = getunuseduserstats(stats);
		    ustats->used = 1;
		    strncpy(ustats->username, username, 32);
		    strncpy(ustats->groupname, groupname, 32);
		    ustats->outbytes = bytes;
		    ustats->outsecs = secs;
	       }
	       else {
		    ustats->outbytes += bytes;
		    ustats->outsecs += secs;
	       }

	       free(rlsname);
	  }  
     }
     free(line);
}

void line_glftpdlog(const char *lineconst) {
     static regex_t reg_pattern;
     static int reg_pattern_allocated = 0;
#define PRETIMEPATTERN 	"^[A-Za-z]{3} [A-Za-z]{3}[ ]{1,2}[0-9]{1,2} [0-9]{2}:[0-9]{2}:[0-9]{2} [0-9]{4} "
     regmatch_t reg_match[20];

     char *line = strdup(lineconst);

     if (!reg_pattern_allocated) {
	  if( regcomp(&reg_pattern, PRETIMEPATTERN PREREGEX , REG_EXTENDED) ) {
	       printf("Error. Cannot compile glftpd pre line pattern.");
	       exit(-1);
	  }
	  reg_pattern_allocated = 1;
     }

     if (regexec(&reg_pattern, line, 20, reg_match, 0)) {
	  aprintf("gllog > Not a pre glftpd pattern doesnt match :: %s\n",line);
	  free(line);
	  return;
     }

     {
	  struct RLSSTATS *stats;

	  const char *rlsname = line + reg_match[PREMATCHNAME].rm_so;
	  const char *size_str = line + reg_match[PREMATCHSIZE].rm_so;
	  int rlssize;

	  line[reg_match[PREMATCHNAME].rm_eo] = 0;
	  line[reg_match[PREMATCHSIZE].rm_eo] = 0;

#ifdef PRESIZEADJUST
	  rlssize = (int)( atof(size_str) PRESIZEADJUST );
#else
	  rlssize = (int)( atof(size_str) );
#endif
	  
	  aprintf("gllog > pre of %s (%dkb size)\n",rlsname,rlssize);

	  stats = getunusedrlsstats();
	  stats->used = 1;
	  stats->pretime = time(NULL);
	  stats->mtime = time(NULL);
	  strcpy(stats->rlsname, rlsname);
	  stats->rlssize = rlssize;

	  stats->outbytes = 0;
	  stats->outsecs = 0;
     }     
     free(line);
}

void poll_finished(int flushall) {
     int n;
     time_t now = time(NULL);
     struct RLSSTATS *stats;
     struct USERSTATS *ustats;
     char outbuffer[1024], fastestbuffer[256];

     double tag_outmbytes, tag_outspeed, tag_outtimes;
     int tag_numusers;

     struct REPLACETAG taglist[] = {
	  { "RLS", 	FTR_STRING,	NULL },
	  { "RLSSIZE", 	FTR_DOUBLE,	NULL },
	  { "OUTMBYTES", FTR_DOUBLE,	NULL },
	  { "OUTSPEED", FTR_DOUBLE,	NULL },
	  { "OUTTIMES", FTR_DOUBLE,	NULL },
	  { "FASTEST", 	FTR_STRING,	NULL },
	  { "NUMUSERS",	FTR_INTEGER,	NULL },
	  { NULL,	FTR_NONE,	NULL }
     };

     taglist[2].val = &tag_outmbytes;
     taglist[3].val = &tag_outspeed;
     taglist[4].val = &tag_outtimes;
     taglist[6].val = &tag_numusers;

     for(n = 0; n < rlsstatslistlen; n++) {
	  if (!rlsstatslist[n].used) continue;

	  if (!flushall) {
	       /* wait minimum secs after pre for ppl to notice pres */
	       if (now - rlsstatslist[n].pretime < MINSECAFTERPRETIME) continue;
	  
	       /* wait for no transfers in 60sec */
	       if (now - rlsstatslist[n].mtime < IDLETRANSFERSEC) continue;
	  }

	  stats = &rlsstatslist[n];

	  ustats = getmaxuserstats(stats);

	  taglist[0].val = stats->rlsname;
	  taglist[1].val = &stats->rlssize;
	  tag_outmbytes = (float)stats->outbytes / 1024/1024;
	  tag_outspeed = stats->outbytes / 1024 / (stats->outsecs > 0 ? stats->outsecs : 1);
	  tag_outtimes = (float)stats->outbytes / (float)stats->rlssize / 1024;

	  if (ustats) {
	       struct REPLACETAG fastest[] = {
		    { "USER",	FTR_STRING,	NULL },
		    { "GROUP", 	FTR_STRING,	NULL },
		    { "MBYTES", FTR_DOUBLE,	NULL },
		    { "SPEED", 	FTR_DOUBLE,	NULL },
		    { NULL,	FTR_NONE,	NULL }
	       };

	       double tag_mbytes = (float)ustats->outbytes / 1024/1024;
	       double tag_speed  = (float)ustats->outbytes / 1024 / (ustats->outsecs > 0 ? ustats->outsecs : 1);

	       fastest[0].val = ustats->username;
	       fastest[1].val = ustats->groupname;
	       fastest[2].val = &tag_mbytes;
	       fastest[3].val = &tag_speed;

	       taglist[5].val = tagreplace(FASTEST_MSG, fastestbuffer, 256, fastest);

	       tag_numusers = getnumuser(stats);
	  }
	  else {
	       taglist[5].val = "";
	       tag_numusers = 0;
	  }

	  tagreplace(PRETRAF_MSG, outbuffer, 1024, taglist);
	  glprintf("%s", outbuffer);
	  
	  if (stats->userlist) {
	       free(stats->userlist);
	  }
	  stats->userlist = NULL;
	  stats->userlistlen = 0;
	  stats->used = 0;
     }
}

void main_writepidfile(const char *pidfile, pid_t pid)
{
     FILE *pf;

     if (!pidfile || !*pidfile) return;

     pf = fopen(pidfile, "w");
     if (pf == NULL) {
	  printf("Cannot create pidfile %s: %s", pidfile, strerror(errno));
	  return;
     }
     fprintf(pf, "%d", pid);
     fclose(pf);
}

int main_checkpidfile(const char *pidfile)
{
     FILE *pf;
     int cpid;
     char procpidpath[256];
     char exepath[512];

     if (!pidfile || !*pidfile) return 0;

     pf = fopen(pidfile, "r");
     if (pf == NULL) {
	  printf("Cannot read pidfile %s: %s", pidfile, strerror(errno));
	  return 0;
     }

     if (fscanf(pf, "%d", &cpid) != 1) {
	  fclose(pf);
	  return 0;
     }

     fclose(pf);
     
     snprintf(procpidpath, 256, "/proc/%d/exe", cpid);

     if (readlink(procpidpath, exepath, sizeof(exepath)) <= 0) {
	  return 0;
     }

     if (strstr(exepath, "f-pretraffic") != NULL) {
	  /* printf("Already running as pid %d\n", cpid); */
	  return 1;
     }

     return 0;
}

int main(int argc, char *argv[]) {
     struct TAILINFO ti_xferlog, ti_glftpdlog;
     int dofork = 1;
     int dotestread = 0;
     const char *pidfile = NULL;
     int dopidcheck = 0;     
     int n;

     aprintf_output = 0;

     if (argc > 1) {
	  n = 1;
	  while(n < argc) {
	       if (strcmp(argv[n],"-h") == 0) {
		    printf("Usage: %s <options>\n",argv[0]);
		    printf("Options: -d = output debug msgs and dont demonize\n");
		    printf("         -n = dont demonize\n");
		    printf("         -t = test processor by reading all of current logs\n");
		    printf("         -check = check if process in pidfile is running, if not start up.\n");
		    printf("         -pidfile <file> = write (or check) pid number to file\n");
		    return 0;
	       }
	       else if (strcmp(argv[n],"-d") == 0) {
		    dofork = 0;
		    aprintf_output = 1;
	       }
	       else if (strcmp(argv[n],"-n") == 0) {
		    dofork = 0;
	       }
	       else if (strcmp(argv[n],"-t") == 0) {
		    dotestread = 1;
	       }
	       else if (strcmp(argv[n],"-check") == 0) {
		    dopidcheck = 1;
	       }
	       else if (strcmp(argv[n],"-pidfile") == 0 && n+1 < argc) {
		    n++;
		    pidfile = argv[n];
	       }
	       else {
		    printf("Unknown parameter %s", argv[n]);
		    return 0;
	       }
	       n++;
	  }
     }
     
     if (dotestread) {
	  char line[1034];
	  FILE *f;

	  printf("Reading whole glftpd.log.\n");
	  f = fopen("/glftpd/ftp-data/logs/glftpd.log", "r");

	  while( fgets(line, 1024, f) ) {
	       line[strlen(line)-1] = 0;
	       line_glftpdlog(line);
	  }
	  fclose(f);

	  printf("Reading whole xferlog log.\n");

	  f = fopen("/glftpd/ftp-data/logs/xferlog", "r");

	  while( fgets(line, 1024, f) ) {
	       line[strlen(line)-1] = 0;
	       line_xferlog(line);
	  }

	  fclose(f);
     
	  glprintf_stdout = 1;

	  poll_finished(1);
	  return 0;
     }

     if (dopidcheck) {
	  if (!pidfile) pidfile = "./f-pretraffic.pid";

	  if (main_checkpidfile(pidfile)) {
	       /* already running fine */
	       return 0;
	  }
     }

     ti_xferlog.fd = 0;
     ti_xferlog.path = GLROOT XFERLOGPATH;

     ti_glftpdlog.fd = 0;
     ti_glftpdlog.path = GLROOT GLLOGPATH;

     if (!tail_reinit(&ti_xferlog)) {
	  printf("Error opening tail of xferlog. Path: %s\n", GLROOT XFERLOGPATH);
	  return 0;
     }

     if (!tail_reinit(&ti_glftpdlog)) {
	  printf("Error opening tail of glftpd. Path: %s\n", GLROOT GLLOGPATH);
	  return 0;
     }

     if (dofork) {
	  int r = fork();
	  if (r > 0) {
	       printf("%s forked into background as pid %d.\n", argv[0], r);
	       return 0;
	  }
	  /* else drop through */

	  /* Become a process/session group leader. */
	  setsid();
	  r = fork();
	  if (r != 0) {
	       if (r < 0) {
		    printf("Second fork into background failed.\n");
	       }
	       return 0;
	  }
     }

     if (pidfile) {
	  main_writepidfile(pidfile , getpid());
     }

     if (dofork) {
	  /* Avoid keeping any directory in use. */
	  chdir("/");

	  close(0);
	  close(1);
	  close(2);
     }


     while(1) {

	  tail_poll(&ti_xferlog, &line_xferlog);

	  tail_poll(&ti_glftpdlog, &line_glftpdlog);  

	  poll_finished(0);

	  sleep(1);
     }

     /* Never happens */
     return 0;
}
