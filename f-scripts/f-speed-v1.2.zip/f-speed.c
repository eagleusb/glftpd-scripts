/* f-speed v1.2: f's fast and flexible !speed for a glftpd sitebot */
/* $Date: 2008-02-05 16:18:57 +0100 (Tue, 05 Feb 2008) $ $Rev: 442 $ */

/* lots of includes */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <stdarg.h>

#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>

#include <regex.h>

#include <unistd.h>

/* include our config file */
#include CONFIG_H

/* include our config file in hexdata */
#include "inc-config.h"

/* some Limits */
#define MAXPATH         260

/* the data structures */

#if defined(GLFTPD_2_0)

/* for glftpd >= v2.0 at least */
struct glshmstruct
{
    char   tagline[64];           /* The users tagline */
    char   username[24];          /* The username of the user */
    char   status[256];           /* The status of the user, idle, RETR, etc */
    short int ssl_flag;           /* 0 = no ssl, 1 = ssl on control, 2 = ssl on control and data */
    char   host[256];             /* The host the user is comming from (with ident) */
    char   currentdir[256];       /* The users current dir (fullpath) */
    long   groupid;               /* The groupid of the users primary group */
    time_t login_time;            /* The login time since the epoch (man 2 time) */
    struct timeval tstart;        /* replacement for last_update. */
    struct timeval txfer;         /* The time of the last succesfull transfer. */
    unsigned long long bytes_xfer; /* bytes transferred so far. */
    unsigned long long bytes_txfer; /* bytes transferred in the last loop (speed limiting) */
    pid_t  procid;                /* The process id of the process */
};

typedef unsigned long long      bytes_xfer_t;
#define FTR_BYTESXFER_T         FTR_LONGLONG

#else

/* for glftpd v1.3 */
struct glshmstruct
{
    char   tagline[64];           /* The users tagline */
    char   username[24];          /* The username of the user */
    char   status[256];           /* The status of the user, idle, RETR, etc */
    char   host[256];             /* The host the user is comming from (with ident) */
    char   currentdir[256];       /* The users current dir (fullpath) */
    long   groupid;               /* The groupid of the users primary group */
    time_t login_time;            /* The login time since the epoch (man 2 time) */
    struct timeval tstart;        /* replacement for last_update. */
    unsigned long bytes_xfer;     /* bytes transferred so far. */
    pid_t  procid;                /* The processor id of the process */
};

typedef unsigned long           bytes_xfer_t;
#define FTR_BYTESXFER_T         FTR_INTEGER

#endif

/* f-tagreplace.h (r1114): C function include for f generic tag replacer */

enum { FTR_NONE, FTR_INTEGER, FTR_LONGLONG, FTR_DOUBLE, FTR_STRING, FTR_DATE, FTR_TIMEINTERVAL };

struct REPLACETAG
{
    const char* tag;
    int         type;
    const void* val;
};

inline int addreplace(struct REPLACETAG *taglist, int taglistlen, const char *tag, int tagtype, const void *val)
{
    int n;
    for(n = 0; n < taglistlen && taglist[n].tag; n++) { }
    if (n >= taglistlen) return -1;

    taglist[n].tag = tag;
    taglist[n].type = tagtype;
    taglist[n].val = val;

    return n;
}

inline int addreplace_integer(struct REPLACETAG *taglist, int taglistlen, const char *tag, const int *val)
{
    return addreplace(taglist, taglistlen, tag, FTR_INTEGER, val);
}
inline int addreplace_longlong(struct REPLACETAG *taglist, int taglistlen, const char *tag, const long long *val)
{
    return addreplace(taglist, taglistlen, tag, FTR_LONGLONG, val);
}
inline int addreplace_double(struct REPLACETAG *taglist, int taglistlen, const char *tag, const double *val)
{
    return addreplace(taglist, taglistlen, tag, FTR_DOUBLE, val);
}
inline int addreplace_string(struct REPLACETAG *taglist, int taglistlen, const char *tag, const char *val)
{
    return addreplace(taglist, taglistlen, tag, FTR_STRING, val);
}
inline int addreplace_date(struct REPLACETAG *taglist, int taglistlen, const char *tag, const time_t *val)
{
    return addreplace(taglist, taglistlen, tag, FTR_DATE, val);
}
inline int addreplace_timeinterval(struct REPLACETAG *taglist, int taglistlen, const char *tag, const unsigned int *val)
{
    return addreplace(taglist, taglistlen, tag, FTR_TIMEINTERVAL, val);
}

/* build a full replacement list: length times follows the arguments
   const char* tag, int tagtype, const char *val */
struct REPLACETAG *replacelist_malloc(int length, ...)
{
    struct REPLACETAG *list;
    va_list ap;
    int n;

    list = malloc((length+1) * sizeof(struct REPLACETAG));
    memset(list, 0, (length+1) * sizeof(struct REPLACETAG));

    va_start(ap, length);

    for(n = 0; n < length; n++) {
        list[n].tag = va_arg(ap, const char *);
        list[n].type = va_arg(ap, int);
        list[n].val = va_arg(ap, const void *);
    }

    va_end(ap);
    return list;
}

/* tagreplace Parameters:
   pattern = use supplied string with %TAG%s
   outbuffer = output buffer of size outlen
   taglist = array of replacement tags
*/

/* syntax %VAR-4% for integer,
   syntax %VAR-4.5% for double decimal points
   syntax %VAR-YYYY-MM-DD-hh-mm-ss% for dates
   syntax %VAR-DD% for time intervals

   following strings will be replaced in the format of a date:
   YYYY = four digit year
   YY = two digit year (avoid)
   MM = two digit month number
   MMM = three letter abbreviation for the month
   MMMM = full month name
   DD = two digit day of month number
   hh = two digit 24h-clock time of day
   ii = two digit 12h-clock time of day
   pp = either am or pm of 12h-clock
   mm = two digit minute
   ss = two digit seconds
   other character sequences are copied.

   If no format is specified for date types it defaults to
   YYYY-MM-DD HH:MM:SS
*/

const char* tagreplace(const char *pattern, char *outbuffer, int outlen, struct REPLACETAG *taglist)
{
    char *out = outbuffer;
    int outleft;

    if (!pattern) return "(null)";

    while( *pattern != 0 && (outleft = outlen - (out - outbuffer) - 1) > 0) {
        if (*pattern == '%') {
            if (pattern[1] == '%') {
                *out++ = '%';
                pattern++;
            }
            else if (strncasecmp(pattern,"%BOLD%",6) == 0) {
                *out++ = 0x02;
                pattern += 5;
            }
            else if (strncasecmp(pattern,"%COLOR%",7) == 0) {
                *out++ = 0x03;
                pattern += 6;
            }
            else if (strncasecmp(pattern,"%ULINE%",7) == 0) {
                *out++ = 0x1F;
                pattern += 6;
            }
            else {
                int bad = 0, n, sl;
                int digits = 0, decimals = 0;

                int haveformated = 0;
                char formated[256];

                for(n = 0; taglist && taglist[n].tag; n++) {
                    if (taglist[n].type == FTR_NONE) continue;

                    sl = strlen(taglist[n].tag);
                    if (strncasecmp(pattern+1, taglist[n].tag, sl) != 0) continue;

                    if (pattern[1+sl] == '-') {
                        if (taglist[n].type == FTR_INTEGER || taglist[n].type == FTR_LONGLONG) {
                            const char *modifier = pattern + 1+sl+1;

                            while(*modifier != '%') {
                                if (*modifier >= '0' && *modifier <= '9') {
                                    digits = digits * 10 + (*modifier - '0');
                                }
                                else { bad = 1; break; }
                                modifier++;
                                sl++;
                            }
                            if (bad) continue;
                            sl++;
                        }
                        else if (taglist[n].type == FTR_STRING) {
                            const char *modifier = pattern + 1+sl+1;

                            while(*modifier != '%') {
                                if (*modifier >= '0' && *modifier <= '9') {
                                    digits = digits * 10 + (*modifier - '0');
                                }
                                else { bad = 1; break; }
                                modifier++;
                                sl++;
                            }
                            if (bad) continue;
                            sl++;
                        }
                        else if (taglist[n].type == FTR_DOUBLE) {
                            const char *modifier = pattern + 1+sl+1;
                            int *val = &digits;
                            while(*modifier != '%') {
                                if (*modifier >= '0' && *modifier <= '9') {
                                    *val = *val * 10 + (*modifier - '0');
                                }
                                else if (*modifier == '.' && taglist[n].type == FTR_DOUBLE) {
                                    if (val == &digits) { val = &decimals; }
                                    else { bad = 1; break; }
                                }
                                else { bad = 1; break; }
                                modifier++;
                                sl++;
                            }
                            if (bad) continue;
                            sl++;
                        }
                        else if (taglist[n].type == FTR_DATE) {
                            const char *modifier = pattern + 1+sl+1;
                            char *outf = formated;
                            const char *addtoout;
                            struct tm *localtimeconv = NULL;

                            if (taglist[n].val) {
                                localtimeconv = localtime((time_t*)taglist[n].val);
                            }

                            while(*modifier != '%') {
                                if (outf + 16 > formated + sizeof(formated)) { bad = 1; break; }

                                addtoout = NULL;

                                if (*(long*)modifier == *(long*)"YYYY") {
                                    addtoout = "%Y";
                                    modifier += 3; sl += 3;
                                }
                                else if (*(short*)modifier == *(short*)"YY") {
                                    addtoout = "%y";
                                    modifier += 1; sl += 1;
                                }
                                else if (*(long*)modifier == *(long*)"MMMM") {
                                    addtoout = "%B";
                                    modifier += 3; sl += 3;
                                }
                                else if (*(short*)modifier == *(short*)"MM" &&
                                         *(modifier+2) == 'M')
                                {
                                    addtoout = "%b";
                                    modifier += 2; sl += 2;
                                }
                                else if (*(short*)modifier == *(short*)"MM") {
                                    addtoout = "%m";
                                    modifier += 1; sl += 1;
                                }
                                else if (*(short*)modifier == *(short*)"DD") {
                                    addtoout = "%d";
                                    modifier += 1; sl += 1;
                                }
                                else if (*(short*)modifier == *(short*)"hh") {
                                    addtoout = "%H";
                                    modifier += 1; sl += 1;
                                }
                                else if (*(short*)modifier == *(short*)"ii") {
                                    addtoout = "%I";
                                    modifier += 1; sl += 1;
                                }
                                else if (*(short*)modifier == *(short*)"pp") {
                                    addtoout = "%P";
                                    modifier += 1; sl += 1;
                                }
                                else if (*(short*)modifier == *(short*)"mm") {
                                    addtoout = "%M";
                                    modifier += 1; sl += 1;
                                }
                                else if (*(short*)modifier == *(short*)"ss") {
                                    addtoout = "%S";
                                    modifier += 1; sl += 1;
                                }
                                else {
                                    *outf++ = *modifier;
                                }

                                if (addtoout) {
                                    if (localtimeconv) {
                                        outf += strftime(outf, outf - formated + sizeof(formated) - 8,
                                                         addtoout, localtimeconv);
                                    }
                                    else {
                                        *outf++ = 'N'; *outf++ = 'N';
                                    }
                                }

                                modifier++;
                                sl++;
                            }
                            if (bad) continue;
                            if (outf > formated) {
                                haveformated = 1;
                                *outf = 0;
                            }
                            sl++;
                        }
                        else {
                            continue;
                        }
                    }
                    else if (pattern[1+sl] != '%') continue;

                    if (taglist[n].type == FTR_INTEGER) {
                        out += snprintf(out, outleft, "%*ld", digits, *(long int*)taglist[n].val);
                    }
                    else if (taglist[n].type == FTR_LONGLONG) {
                        out += snprintf(out, outleft, "%*lld", digits, *(long long int*)taglist[n].val);
                    }
                    else if (taglist[n].type == FTR_STRING) {
                        out += snprintf(out, outleft, "%*s", digits, (const char*)taglist[n].val);
                    }
                    else if (taglist[n].type == FTR_DOUBLE) {
                        out += snprintf(out, outleft, "%*.*f", digits, decimals, *(double*)taglist[n].val);
                    }
                    else if (taglist[n].type == FTR_DATE) {
                        if (haveformated) {
                            out += snprintf(out, outleft, "%s", formated);
                        }
                        else if (!taglist[n].val) {
                            out += snprintf(out, outleft, "(nulldate)");
                        }
                        else {
                            out += strftime(out, outleft, "%Y-%m-%d %H:%M:%S", localtime((time_t*)taglist[n].val));
                        }
                    }
                    else {
                        out += snprintf(out, outleft, "ERRORinPROG");
                    }

                    pattern += sl + 1;
                    break;
                }
                if (!taglist[n].tag) {
                    *out++ = *pattern;
                }
            }
        }
        else {
            *out++ = *pattern;
        }

        pattern++;
    }

    *out = 0;
    return outbuffer;
}

/* end of f-tagreplace.h (r1114) */

/* translated userinfo */

struct userinfo
{
    const char* name;
    pid_t       pid;
    const char* tagline;
    const char* status;
    const char* host;
    const char* path;
    bytes_xfer_t bytesxfer;
    bytes_xfer_t kbytesxfer;

    double speed;

    const char* currentfile;
    bytes_xfer_t bytesmax;
    bytes_xfer_t kbytesmax;

    double      dlpercent;
};

/* other program data */

regex_t hidedirregex;

/* check if a username is in the list */
int ishiddenuser(const char *testuser)
{
#ifdef HIDEUSERLIST
    {
        char *occur = HIDEUSERLIST-1;
        int testlen = strlen(testuser);
        while( (occur = strstr(occur+1, testuser)) ) {
            if (occur[-1] != ',' && occur != HIDEUSERLIST) continue;
            if (occur[testlen] != ',' && occur[testlen] != '\0') continue;
            return 1;
        }
    }
#endif
#ifdef HIDEUSERFILE
    {
        static char **hideuserfilelist;
        static int hideuserfilelistnum;

        if (!hideuserfilelist) {
            FILE *f;
            char line[4096], *linet;

            hideuserfilelistnum = 0;
            if ( (f = fopen(HIDEUSERFILE, "r")) )
            {
                while( fgets(line, sizeof line, f) ) {
                    hideuserfilelistnum++;
                }

                hideuserfilelistnum++;
                hideuserfilelist = malloc(sizeof(char *) * hideuserfilelistnum);
                memset(hideuserfilelist, 0, sizeof(char *) * hideuserfilelistnum);

                fseek(f,0,SEEK_SET);
                hideuserfilelistnum = 0;

                while( fgets(line, sizeof line, f) ) {
                    if (*line == '\0' || *line == '\n' || *line == '\r') continue;
                    linet = line;
                    while( *linet != '\0' ) {
                        if (*linet == '\n') *linet = '\0';
                        if (*linet == '\r') *linet = '\0';
                        linet++;
                    }

                    hideuserfilelist[hideuserfilelistnum++] = strdup(line);
                }

                fclose(f);
            }
        }
        if (hideuserfilelist) {
            int i;
            for (i = 0; i < hideuserfilelistnum; i++) {
                if (strcmp(hideuserfilelist[i], testuser) == 0) return 1;
            }
        }
    }
#endif
    return 0;
}

/* check if a path matches the hidden dir regex */
int ishiddenpath(const char *testpath)
{
#ifdef HIDEDIRREGEX
    regmatch_t matches[1];

    if (regexec(&hidedirregex, testpath, 1, matches, 0) == 0) {
        return 1;
    }
#endif
    return 0;
}

/* find the last component of a path */

const char *fbasename(const char *path)
{
    const char *rocc = rindex(path, '/');
    if (rocc == NULL) return NULL;
    return rocc+1;
}

/* calculate the speed in kb/s from the two params */

double calcspeed(struct timeval tvstart, bytes_xfer_t bytes_xfer)
{
    struct timeval tvnow;
    double usertransferperiod;

    /* should we get this only once? */
    gettimeofday(&tvnow, (struct timezone *)0 );

    usertransferperiod = (tvnow.tv_sec + tvnow.tv_usec * 0.000001) - (tvstart.tv_sec + tvstart.tv_usec * 0.000001);
    return (bytes_xfer / 1024.0) / usertransferperiod;
}

int timevaleq(struct timeval t1, struct timeval t2)
{
    return (t1.tv_sec == t2.tv_sec && t1.tv_usec == t2.tv_usec);
}

/* translates a user from shm into a more nice format for outputting */

void translate_user(struct glshmstruct *gl, struct userinfo *ui)
{
    if (!ui) return;

    ui->name = gl->username;
    ui->pid = gl->procid;
    ui->tagline = gl->tagline;
    ui->status = gl->status;
    ui->host = gl->host;

    if (strncmp(gl->currentdir,"/site",5) == 0) {
        ui->path = gl->currentdir + 5;
        if (*ui->path == 0) { ui->path = "/"; }
    }
    else {
        ui->path = gl->currentdir;
    }

    ui->currentfile = fbasename(ui->path);

    if (ui->currentfile != NULL && *ui->currentfile != '\0') {
        struct stat finfo;
        char pathbuffer[300];

        snprintf(pathbuffer, sizeof pathbuffer, "%s/%s", GLFTPDROOT, gl->currentdir);
        if (stat(pathbuffer, &finfo) == 0) {
            ui->bytesmax = finfo.st_size;
            ui->kbytesmax = finfo.st_size / 1024;
        }
        else {
            ui->bytesmax = 0;
            ui->kbytesmax = 0;
        }
    }

    ui->bytesxfer = gl->bytes_xfer;
    ui->kbytesxfer = gl->bytes_xfer / 1024;

    ui->speed = calcspeed(gl->tstart, gl->bytes_xfer);

    if (ui->bytesmax == 0) ui->dlpercent = 0;
    else ui->dlpercent = (float)ui->bytesxfer / (float)ui->bytesmax * 100;
}

int userexist(const char *username)
{
    char filepath[MAXPATH];

#ifdef GLUSERDB
    snprintf(filepath, MAXPATH, "%s/%s", GLUSERDB, username);

    return access(filepath, R_OK) == 0;
#else
    return 1;
#endif
}

const char* loadusergroup(const char *username)
{
    static char groupbuff[32];
#ifdef GLUSERDB
    FILE *f;
    char filepath[MAXPATH];
    char line[1024];
    regex_t reg;
    regmatch_t rmatch[2];

    snprintf(filepath, MAXPATH, "%s/%s", GLUSERDB, username);
    f = fopen(filepath,"r");
    if (!f)
    {
        strcpy(groupbuff,"NoGroup");
        return groupbuff;
    }
    else
    {
        *groupbuff = 0;
        regcomp(&reg, "^GROUP ([^\n\r ]+)", REG_EXTENDED);

        while( fgets(line, sizeof line, f) ) {
            if (regexec(&reg, line, 2, rmatch, 0) == 0) {
                memset(groupbuff, 0, sizeof groupbuff);
                strncpy(groupbuff, line + rmatch[1].rm_so, rmatch[1].rm_eo - rmatch[1].rm_so);
                break;
            }
        }
        regfree(&reg);
        fclose(f);

        if (*groupbuff == 0) strcpy(groupbuff,"NoGroup");
        return groupbuff;
    }
#else
#warning "You must #define GLUSERDB if you wish to use the %GROUP% macro"
    strcpy(groupbuff,"NoGroup");
    return groupbuff;
#endif
}

/* f-speed part */

void f_speed(struct glshmstruct *glshm, int glshmuser, const char *username)
{
    int i;
    int exactmatch = 0;
    struct userinfo ui;
    struct REPLACETAG *taglist;
    char buffer[1024];

    /* First we scan though all usernames looking for an exact match */
    for (i = 0; i < glshmuser; i++)
    {
        if (glshm[i].procid == 0) continue;
        if (ishiddenuser(glshm[i].username)) continue;
        if (ishiddenpath(glshm[i].currentdir)) continue;

        if (strcmp(username, glshm[i].username) == 0) {
            exactmatch = 1;
            break;
        }
    }

    /* No match found. Go look again this time case-insensitive */
    /* If we find two matching but different usernames, we croak */
    if (!exactmatch) {
        const char *insenmatch = NULL;
        int nomatch = 1;

        for (i = 0; i < glshmuser; i++)
        {
            if (glshm[i].procid == 0) continue;
            if (ishiddenuser(glshm[i].username)) continue;
            if (ishiddenpath(glshm[i].currentdir)) continue;

            if (strcasecmp(username, glshm[i].username) == 0) {
                nomatch = 0;
                if (!insenmatch) {
                    insenmatch = glshm[i].username;
                }
                else if (strcmp(glshm[i].username, insenmatch) == 0) {
                    /* same user logged in twice */
                }
                else {
                    /* two users with names only differing in case are online */
                    nomatch = 1;
                    break;
                }
            }
        }

        if (nomatch)
        {
            if (userexist(username)) {
#ifndef MSG_NOTONLINE
#error "You must #define MSG_NOTONLINE in config.h"
#endif
                taglist = replacelist_malloc(2,
                                             "USER",    FTR_STRING,     username,
                                             "GROUP",   FTR_STRING,     loadusergroup(username));

                printf("%s\n", tagreplace(MSG_NOTONLINE, buffer, sizeof(buffer), taglist));

                free(taglist);
            }
            else {
#ifndef MSG_NOTEXIST
#error "You must #define MSG_NOTEXIST in config.h"
#endif
                taglist = replacelist_malloc(1,
                                             "USER",    FTR_STRING,     username);

                printf("%s\n", tagreplace(MSG_NOTEXIST, buffer, sizeof(buffer), taglist));

                free(taglist);
            }
            return;
        }
    }

    for (i = 0; i < glshmuser; i++)
    {
        if (glshm[i].procid == 0) continue;
        if (ishiddenuser(glshm[i].username)) continue;
        if (ishiddenpath(glshm[i].currentdir)) continue;

        if (strcasecmp(username, glshm[i].username) != 0) continue;

        translate_user(&glshm[i], &ui);

        taglist = replacelist_malloc(13,
                                     "USER",            FTR_STRING,     ui.name,
                                     "GROUP",           FTR_STRING,     loadusergroup(username),
                                     "PID",             FTR_INTEGER,    &ui.pid,
                                     "TAGLINE",         FTR_STRING,     ui.tagline,
                                     "HOST",            FTR_STRING,     ui.host,
                                     "PATH",            FTR_STRING,     ui.path,
                                     "FILE",            FTR_STRING,     ui.currentfile,
                                     "BYTES",           FTR_BYTESXFER_T,&ui.bytesxfer,
                                     "KBYTES",          FTR_BYTESXFER_T,&ui.kbytesxfer,
                                     "MAXBYTES",        FTR_BYTESXFER_T,&ui.bytesmax,
                                     "MAXKBYTES",       FTR_BYTESXFER_T,&ui.kbytesmax,
                                     "DLPERCENT",       FTR_DOUBLE,     &ui.dlpercent,
                                     "SPEED",           FTR_DOUBLE,     &ui.speed);

        /* Uploader */
        if ((strncasecmp(glshm[i].status, "STOR", 4) == 0 || strncasecmp(glshm[i].status, "APPE", 4) == 0) && glshm[i].bytes_xfer != 0)
        {
#ifndef MSG_UPLOAD
#error "You must #define MSG_UPLOAD in config.h"
#endif
            printf("%s\n", tagreplace(MSG_UPLOAD, buffer, sizeof(buffer), taglist));
        }
        /* Downloader */
        else if (strncasecmp(glshm[i].status, "RETR", 4) == 0 && glshm[i].bytes_xfer != 0) {
#ifndef MSG_DOWNLOAD
#error "You must #define MSG_DOWNLOAD in config.h"
#endif
            printf("%s\n", tagreplace(MSG_DOWNLOAD, buffer, sizeof(buffer), taglist));
        }
        /* Idle for more than 5 sec */
        else if (time(NULL) - glshm[i].tstart.tv_sec > 5) {
#ifndef MSG_IDLE
#error "You must #define MSG_IDLE in config.h"
#endif
            printf("%s\n", tagreplace(MSG_IDLE, buffer, sizeof(buffer), taglist));
        }
        /* Not idle. Doing something else (usually listing). */
        else {
#ifndef MSG_ACTIVE
#error "You must #define MSG_ACTIVE in config.h"
#endif
            printf("%s\n", tagreplace(MSG_ACTIVE, buffer, sizeof(buffer), taglist));
        }

        free(taglist);
    }
}

/* f-bandwidth part */

void f_bandwidth(struct glshmstruct *glshm, int glshmuser)
{
    int i;
    double ulspeed = 0, dlspeed = 0, allspeed = 0;
    unsigned int uluser = 0, dluser = 0, idleuser = 0, xferuser = 0, alluser = 0;
    struct REPLACETAG *taglist;
    char buffer[1024];

    for (i = 0; i < glshmuser; i++) {
        if (glshm[i].procid == 0) continue;
        if (ishiddenuser(glshm[i].username)) continue;
        if (ishiddenpath(glshm[i].currentdir)) continue;

        if (strncasecmp(glshm[i].status, "STOR", 4) == 0 || strncasecmp(glshm[i].status, "APPE", 4) == 0) {
            uluser++;
            ulspeed += calcspeed(glshm[i].tstart, glshm[i].bytes_xfer);
        }
        else if (strncasecmp(glshm[i].status, "RETR", 4) == 0) {
            dluser++;
            dlspeed += calcspeed(glshm[i].tstart, glshm[i].bytes_xfer);
        }
        else {
            idleuser++;
        }
    }

    allspeed = ulspeed + dlspeed;
    xferuser = uluser + dluser;
    alluser = uluser + dluser + idleuser;

#ifndef MSG_BANDWIDTH
#error "You must #define MSG_BANDWIDTH in config.h"
#endif

    taglist = replacelist_malloc(8,
                                 "ULSPEED",     FTR_DOUBLE,     &ulspeed,
                                 "DLSPEED",     FTR_DOUBLE,     &dlspeed,
                                 "ALLSPEED",    FTR_DOUBLE,     &allspeed,
                                 "ULUSER",      FTR_INTEGER,    &uluser,
                                 "DLUSER",      FTR_INTEGER,    &dluser,
                                 "XFERUSER",    FTR_INTEGER,    &xferuser,
                                 "IDLEUSER",    FTR_INTEGER,    &idleuser,
                                 "ALLUSER",     FTR_INTEGER,    &alluser);

    printf("%s\n", tagreplace(MSG_BANDWIDTH, buffer, sizeof(buffer), taglist));

    free(taglist);
}

/* main program */

int main(int argc, char *argv[])
{
    const char *basenamestr;

    struct glshmstruct *glshm;
    int glshmid, glshmuser;
    char buffer[256];

    if (argc == 2 && strcmp(argv[1], "dumpconfig") == 0 &&
        getenv("USER") && strcmp(getenv("USER"), "root") == 0)
    {
        fwrite(confighdata, 1, sizeof confighdata, stdout);
        return 0;
    }

    /* attach shared memory */
#ifndef GLSHMKEY
#error "You must the glftpd shared memory key with #define GLSHMKEY"
#endif
    if ((glshmid = shmget( (key_t)GLSHMKEY, 0, 0)) == -1)
    {
        printf("%s: glftpd doesnt seem to be running.\n",argv[0]);
        return 0;
    }

    glshm = (struct glshmstruct *)shmat(glshmid, NULL, SHM_RDONLY);

    if (glshm == (struct glshmstruct *)-1)
    {
        printf("%s: (SHMAT) failed!\n",argv[0]);
        return 1;
    }
    {
        struct shmid_ds glshmstat;
        shmctl(glshmid, IPC_STAT, &glshmstat);

        if (glshmstat.shm_segsz % sizeof( struct glshmstruct ) != 0) {
            printf("Error: shared memory size (%d) is not a factor of the shminfo block size (%d)\n",
                   glshmstat.shm_segsz, sizeof( struct glshmstruct ));
        }

        glshmuser = glshmstat.shm_segsz / sizeof( struct glshmstruct );
    }

#ifdef HIDEDIRREGEX
    if (regcomp( &hidedirregex, HIDEDIRREGEX, REG_NEWLINE | REG_EXTENDED)) {
        printf("%s Cannot compile regex pattern!\n",argv[0]);
        return 1;
    }
#endif

    basenamestr = fbasename(argv[0]);

    if (strcasecmp(basenamestr,"f-bw") == 0 || strcasecmp(basenamestr,"f-bandwidth") == 0)
    {
        if (argc != 1) {
            printf("%s does not take a parameter.",argv[0]);
            return 0;
        }

        f_bandwidth(glshm, glshmuser);
    }
    else
    {
        if (argc != 2) {
#ifndef MSG_NOPARAM
#error "You must #define MSG_NOPARAM in config.h"
#endif
            printf("%s\n", tagreplace(MSG_NOPARAM, buffer, sizeof(buffer), NULL));
            return 0;
        }

        f_speed(glshm, glshmuser, argv[1]);
    }

    return 0;
}
